package bean;

import lombok.Getter;

/**
 * Utilisateur normal 
 * @author small44
 *
 */
@Getter
public class NormalUser extends AbstractUser {
	private int id;

  /**
   * Normal user class
   * @param firstName normal user firstName
   * @param lastName normal user lastName
   * @param age ormal user age;
   */
	public NormalUser(String firstName, String lastName, int age) {
		super(firstName, lastName, age);

	}

}
