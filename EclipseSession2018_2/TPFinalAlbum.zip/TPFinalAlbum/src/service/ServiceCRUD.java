package service;


import java.util.*;

import util.IServiceCRUD;



public class ServiceCRUD<T> implements IServiceCRUD<T>{
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean addBean(Collection<T> col,T bean) {
		if(col == null) {
			return false;
		}
		return col.add(bean);
	
	}
    
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean modifyBean(Collection<T> col, T bean, T newBean) {

		return removeBean(col, bean) && addBean(col,newBean);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public T getBean(Collection<T> col,int index ) {
		T bean=null;
		if(col instanceof List) {
			return ((List<T>)col).get(index);
		}else if(col instanceof Set) {
			bean = (T) new ArrayList(col).get(index);
		}
		return bean;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean removeBean(Collection<T> col, T bean) {
		return col.remove(bean);
	}


}
