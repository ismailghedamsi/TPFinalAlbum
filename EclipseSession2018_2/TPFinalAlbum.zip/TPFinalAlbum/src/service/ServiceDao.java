package service;




import java.io.*;
import java.util.*;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver;
import com.thoughtworks.xstream.io.xml.DomDriver;

import bean.Album;
import bean.Artist;
import bean.Song;
import util.IServiceDao;



public class ServiceDao<T> implements IServiceDao<T> {
	public static String XML_EXTENSION = ".xml";
	public static String  JSON_EXTENSION = ".json";
	  
	@Override
	/**
	 * @inheritDoc
	 */
	public boolean saveBeans(String fileName, Collection<T> c){
	
		XStream stream= null ;
		try {
			if(fileName==null || c==null) {
				return false;
			}
			if(fileName.endsWith(XML_EXTENSION)) {
				stream = new XStream(new DomDriver());
			}else if (fileName.endsWith(JSON_EXTENSION)) {
				stream = new XStream(new JettisonMappedXmlDriver());
				stream.setMode(XStream.NO_REFERENCES);
			}
			aliasing(stream);
			stream.toXML(c, new FileOutputStream(new File(fileName)));
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
		return new File(fileName).exists();
	}
  
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Collection<T> loadBeans(String fileName) {
		XStream stream= null ;
		//On retourne une liste vide si le chargement n'a pas marcher pour eviter 
		// Le NullPointerException
		Collection<T> beans = Collections.emptyList();
		try {
			if(fileName.endsWith(XML_EXTENSION)) {
				stream = new XStream(new DomDriver());
			}else if (fileName.endsWith(JSON_EXTENSION)) {
				stream = new XStream(new JettisonMappedXmlDriver());
				stream.setMode(XStream.NO_REFERENCES);
			}
			
			aliasing(stream);
			beans = (Collection<T>) stream.fromXML(new FileInputStream(new File(fileName)));
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return beans;
	}
	
	/**
	 * Hide the structure of the project in the xml or json file from the client
	 * @param stream the xstream instance
	 */
	public void aliasing(XStream stream) {
		stream.alias("Album", Album.class);
		stream.alias("Student",Artist.class);
		stream.alias("Employee", Song.class);

		
		
	}
	
	
	
}
