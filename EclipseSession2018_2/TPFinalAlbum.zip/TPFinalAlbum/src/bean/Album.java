package bean;

public class Album {

}
