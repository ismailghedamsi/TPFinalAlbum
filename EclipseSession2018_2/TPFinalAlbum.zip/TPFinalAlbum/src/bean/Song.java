package bean;

public class Song {

}
