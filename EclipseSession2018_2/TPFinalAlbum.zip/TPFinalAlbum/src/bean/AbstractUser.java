package bean;

/**
 * 
 * @author small44
 * Absr=tract classe representing normaluser and admin
 */
public class AbstractUser implements Comparable<AbstractUser>{
	private String firstName;
	private String lastName;
	private int age;
	private int id;
	private static int compteur;


	public AbstractUser(String firstName, String lastName, int age) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.id = compteur++;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public int compareTo(AbstractUser o) {
		// TODO Auto-generated method stub
		return o.firstName.compareTo(this.firstName);
	}

	@Override
	public String toString() {
		return "AbstractUser [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age +"]";
	}
	
	
	
	
}
