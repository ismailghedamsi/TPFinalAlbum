package bean;

public class Artist {

}
